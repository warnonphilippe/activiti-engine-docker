package be.civadis.jwt.srv1.client;

import java.io.IOException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import feign.RequestInterceptor;

@Configuration
public class JwtInterceptedFeignConfiguration {

    @Bean(name = "jwtRequestInterceptor")
    public RequestInterceptor getJwtRequestInterceptor() throws IOException {
        return new TokenRelayRequestInterceptor();
    }
}

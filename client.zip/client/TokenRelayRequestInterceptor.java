package be.civadis.ala.client;


import feign.RequestInterceptor;
import feign.RequestTemplate;
import org.springframework.security.core.context.SecurityContextHolder;

import be.civadis.ala.security.SecurityUtils;

public class TokenRelayRequestInterceptor implements RequestInterceptor {

    public static final String AUTHORIZATION = "Authorization";

    @Override
    public void apply(RequestTemplate template) {
        if (SecurityUtils.getCurrentUserJWT().isPresent()){
            template.header(AUTHORIZATION, SecurityUtils.getCurrentUserJWT().get());
        }
    }
}
